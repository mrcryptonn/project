<?php
session_start();
require 'koneksi.php';

// proses login
if (!empty($_GET['aksi'] == 'login')) {
  // validasi text untuk filter karakter khusus dengan fungsi strip_tags()
  $user = $_POST['user'];
  $pass = $_POST['pass'];
  $sql = "SELECT * FROM user WHERE username = ? AND password = md5(?)";
  $row = $koneksi->prepare($sql);
  $row->execute(array($user, $pass));
  $count = $row->rowCount();

  if ($count > 0) {
    $result = $row->fetch();
    $_SESSION['ADMIN'] = $result;
    // status yang diberikan
    echo "<script>window.location='admin.php';</script>";
  } else {
    echo "<script>window.location='login.php?get=failed';</script>";
  }
}

if (!empty($_GET['aksi'] == 'logout')) {
  session_destroy();
  echo "<script>window.location='login.php?signout=success';</script>";
}